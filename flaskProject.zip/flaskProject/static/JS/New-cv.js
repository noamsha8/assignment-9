function bgchange3(){
    var text = document.getElementById("item3").style.backgroundColor="wheat";
}
function bgchange4(){
    var text = document.getElementById("item4").style.backgroundColor="wheat";
}
function bgchange5(){
    var text = document.getElementById("item5").style.backgroundColor="wheat";
}
function bgchange6(){
    var text = document.getElementById("item6").style.backgroundColor="wheat";
}
function bgchange7(){
    var text = document.getElementById("item7").style.backgroundColor="wheat";
}
function bgchange8(){
    var text = document.getElementById("item8").style.backgroundColor="wheat";
}
function bgchange9(){
    var text = document.getElementById("item9").style.backgroundColor="wheat";
}
function bgchange12(){
    var text = document.getElementById("item12").style.backgroundColor="wheat";
}
function bgchange13(){
    var text = document.getElementById("item13").style.backgroundColor="wheat";
}
function bgchange16(){
    var text = document.getElementById("item16").style.backgroundColor="wheat";
}
function bgchange10(){
    var text = document.getElementById("item10").style.backgroundColor="wheat";
}
function bgchange17(){
    var text = document.getElementById("item17").style.backgroundColor="wheat";
}
function bgnormal3(){
    var text = document.getElementById("item3").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal4(){
    var text = document.getElementById("item4").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal5(){
    var text = document.getElementById("item5").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal6(){
    var text = document.getElementById("item6").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal7(){
    var text = document.getElementById("item7").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal8(){
    var text = document.getElementById("item8").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal9(){
    var text = document.getElementById("item9").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal10(){
    var text = document.getElementById("item10").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal12(){
    var text = document.getElementById("item12").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal13(){
    var text = document.getElementById("item13").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal16(){
    var text = document.getElementById("item16").style.backgroundColor="rgb(180, 148, 148)";
}
function bgnormal17(){
    var text = document.getElementById("item17").style.backgroundColor="rgb(180, 148, 148)";
}