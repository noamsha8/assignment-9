
from flask import Flask
from flask import render_template, redirect, url_for, request, session
app = Flask(__name__)
app.secret_key = '123abcd'

@app.route('/')
def new_cv():
    return render_template('New-cv.html')


@app.route('/aboutmyself')
def about_myself():
    return render_template('About Myself.html')


@app.route('/academiceducation')
def academic_education():
    return render_template('Academic Education.html')


@app.route('/academicknowledge')
def academic_knowledge():
    return render_template('Academic Knowledge.html')


@app.route('/army')
def army():
    return render_template('Army.html')


@app.route('/contactme')
def contact_me():
    return render_template('Contact me.html')


@app.route('/highschoolgraduation')
def high_school_graduation():
    return render_template('Highschool Gradiation.html')


@app.route('/insummery')
def in_summery():
    return render_template('In Summery.html')


@app.route('/jobs')
def jobs():
    return render_template('Jobs.html')


@app.route('/assignment9', methods=['GET', 'POST'])
def assignment9():
    users = [{"id":7,"email":"michael.lawson@reqres.in","first_name":"Michael","last_name":"Lawson","avatar":"https://reqres.in/img/faces/7-image.jpg"},
             {"id":8,"email":"lindsay.ferguson@reqres.in","first_name":"Lindsay","last_name":"Ferguson","avatar":"https://reqres.in/img/faces/8-image.jpg"},
             {"id":9,"email":"tobias.funke@reqres.in","first_name":"Tobias","last_name":"Funke","avatar":"https://reqres.in/img/faces/9-image.jpg"},
             {"id":10,"email":"byron.fields@reqres.in","first_name":"Byron","last_name":"Fields","avatar":"https://reqres.in/img/faces/10-image.jpg"},
             {"id":11,"email":"george.edwards@reqres.in","first_name":"George","last_name":"Edwards","avatar":"https://reqres.in/img/faces/11-image.jpg"},
             {"id":12,"email":"rachel.howell@reqres.in","first_name":"Rachel","last_name":"Howell","avatar":"https://reqres.in/img/faces/12-image.jpg"}]
    username = ''
    if request.method == 'GET':
        if 'search' in request.args:
         searchName = request.args['search']
         if searchName == '':
             return render_template('Assignment9.html', users=users)
         else:
          return render_template('Assignment9.html', username=searchName, users=users)

    if request.method == 'POST':

        user= request.form['username']
        session['logged_in'] = True
        session['username'] = user
        return render_template('Assignment9.html')
    return render_template('Assignment9.html')


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session['logged_in'] = False
    session['username'] = ' '
    return render_template('Assignment9.html')

@app.route('/recommendations')
def recommendations():
    return render_template('Recomendations.html')


@app.route('/block')
def block():
    return render_template('Block.html')



if __name__ == '__main__':
    app.run(debug=True)

